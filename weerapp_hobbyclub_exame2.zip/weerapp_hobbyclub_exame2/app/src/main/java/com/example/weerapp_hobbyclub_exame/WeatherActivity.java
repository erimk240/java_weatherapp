package com.example.weerapp_hobbyclub_exame;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class WeatherActivity extends AppCompatActivity {

    private Spinner citySpinner;
    private TextView temperatureTextView;
    private TextView rainStatusTextView;
    private TextView windSpeedTextView;
    private TextView humidityTextView;
    private Button logoutButton;
    private static final String TAG = "WeatherActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        citySpinner = findViewById(R.id.citySpinner);
        temperatureTextView = findViewById(R.id.temperatureTextView);
        rainStatusTextView = findViewById(R.id.rainStatusTextView);
        windSpeedTextView = findViewById(R.id.windSpeedTextView);
        humidityTextView = findViewById(R.id.humidityTextView);
        logoutButton = findViewById(R.id.logoutButton);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.cities_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        citySpinner.setAdapter(adapter);

        citySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String city = parent.getItemAtPosition(position).toString();
                fetchWeatherData(city);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Niets geselecteerd
            }
        });

        // Set an onClick listener on the logout button
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close the application
                finishAffinity();
            }
        });
    }

    private void fetchWeatherData(String city) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        WeatherAPI weatherAPI = retrofit.create(WeatherAPI.class);

        String apiKey = getString(R.string.open_weather_map_api_key); // API-sleutel ophalen
        Log.d(TAG, "Fetching weather data for city: " + city + " with API key: " + apiKey);

        Call<WeatherResponse> call = weatherAPI.getWeather(city, apiKey, "metric");
        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    WeatherResponse weatherResponse = response.body();
                    updateUI(weatherResponse);
                } else {
                    Log.e(TAG, "Response not successful: " + response.message());
                    Toast.makeText(WeatherActivity.this, "Geen weergegevens beschikbaar", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                Log.e(TAG, "Failed to fetch weather data", t);
                Toast.makeText(WeatherActivity.this, "Kan weergegevens niet ophalen", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateUI(WeatherResponse weatherResponse) {
        runOnUiThread(() -> {
            try {
                temperatureTextView.setText("Huidige temperatuur: " + weatherResponse.getMain().getTemp() + "°C");
                rainStatusTextView.setText("Neerslag: " + (weatherResponse.getWeather().get(0).getMain().equals("Rain") ? "Regen" : "Droog"));
                windSpeedTextView.setText("Windsnelheid: " + weatherResponse.getWind().getSpeed() + " km/u");
                humidityTextView.setText("Luchtvochtigheid: " + weatherResponse.getMain().getHumidity() + "%");
            } catch (Exception e) {
                Log.e(TAG, "Error updating UI", e);
                Toast.makeText(WeatherActivity.this, "Fout bij het updaten van de UI", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
