package com.example.weerapp_hobbyclub_exame;

import java.util.List;

public class WeatherResponse {

    private Main main;
    private List<Weather> weather;
    private Wind wind;

    public Main getMain() {
        return main;
    }

    public List<Weather> getWeather() {
        return weather;
    }

    public Wind getWind() {
        return wind;
    }

    public class Main {
        private float temp;
        private int humidity;

        public float getTemp() {
            return temp;
        }

        public int getHumidity() {
            return humidity;
        }
    }

    public class Weather {
        private String main;

        public String getMain() {
            return main;
        }
    }

    public class Wind {
        private float speed;

        public float getSpeed() {
            return speed;
        }
    }
}
